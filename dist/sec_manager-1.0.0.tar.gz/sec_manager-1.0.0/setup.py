# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['sec_manager']

package_data = \
{'': ['*']}

install_requires = \
['Flask-Login>=0.3,<0.4',
 'Flask>=1.1.4,<2.0.0',
 'alembic>=1.6.5,<2.0.0',
 'apache-airflow>=2.1.0,<3.0.0',
 'fastjsonschema>=2.14.5,<3.0.0',
 'flask_appbuilder>=3.3.0,<4.0.0',
 'jmespath>=0.10.0,<0.11.0',
 'jwcrypto>=0.6,<0.7',
 'kubernetes>=17.17.0,<18.0.0']

extras_require = \
{'pydantic': ['pydantic>=1.8.2,<2.0.0', 'email-validator']}

setup_kwargs = {
    'name': 'sec-manager',
    'version': '1.0.0',
    'description': 'Python utilities for datafabric security components',
    'long_description': "# DataFabric Security Components\n\nA custom security manager for use with [Apache\nAirflow][Airflow] inside the [Datafabric Platform].\n\nThis [Security Manager] will validate the JWT tokens from the Datafabric\nenvironment and automatically create or update the user record as appropriate.\n\n\nThis file won't exist until you've run the Airflow webserver at least once in RBAC mode:\n\n```\nAIRFLOW__WEBSERVER__RBAC=true\nairflow webserver --help\n```\n\n## More readings\n\n[Airflow]: https://airflow.apache.org/\n[Security Manager]: https://flask-appbuilder.readthedocs.io/en/latest/security.html#your-custom-security\n",
    'author': 'DataFabric',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/mohamedbenchaliah/datafabric-sec-manager',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'python_requires': '>=3.9.5,<4.0.0',
}


setup(**setup_kwargs)
